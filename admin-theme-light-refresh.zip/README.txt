Admin light theme refresh. Extract from project root with: unzip -o admin-theme-light-refresh.zip
